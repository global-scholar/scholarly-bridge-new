'use client';

import ConferenceRegistration from '@/components/ConferenceRegistration_Component';

export default function RegisterPage() {
  return <ConferenceRegistration />;
}
