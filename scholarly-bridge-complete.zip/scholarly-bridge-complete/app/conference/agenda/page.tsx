'use client';

import ConferenceAgenda from '@/components/ConferenceAgenda_Component';

export default function AgendaPage() {
  return <ConferenceAgenda />;
}
